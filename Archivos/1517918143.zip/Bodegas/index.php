<?php

require_once './controller/BodegaController.php';
require_once './controller/VinoController.php';

if(!isset($_GET['controller'])){
    index();
}else{
switch ($_GET['controller']) {
    case'bodega':
        $bodControl = new BodegaController();
        action($bodControl);       
        break;
    case'vino':
        $vinoControl = new VinoController();
        action($vinoControl);       
        break;
    default:
        index();
        break;
        
}
}

function action($objController) {
    $objController->run($_GET['action']);
}

function index() {
    $bodControl=new BodegaController();
       $datos= $bodControl->getAll();
       $bodControl->view('index', $datos);
}