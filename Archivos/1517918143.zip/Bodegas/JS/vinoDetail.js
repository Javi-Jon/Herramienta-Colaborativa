var tipo=$('[name=tipovinoDefault').val();
$('#opt'+tipo+'').attr('selected','selected');
