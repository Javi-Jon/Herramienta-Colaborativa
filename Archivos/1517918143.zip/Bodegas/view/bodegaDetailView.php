<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>bodega View</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    </head>
    <body>
        <div class="container">
            <h1><?= $datos->getNombre(); ?></h1>
            <form method="POST" action="./index.php?controller=bodega&action=u">
                <input type="hidden" name="id" value="<?= $datos->getId(); ?>">
                <input type="hidden" name="hotelDefault" value="<?= $datos->getHotel(); ?>">
                <input type="hidden" name="restauranteDefault" value="<?= $datos->getRestaurante(); ?>">

                <input  class="form-group form-control data"type="text" value="<?= $datos->getNombre(); ?>" name="nombre" readonly>
                <input  class="form-group form-control data"type="text" value="<?= $datos->getProvincia(); ?>" name="provincia" readonly>
                <input  class="form-group form-control data"type="text" value="<?= $datos->getCiudad(); ?>" name="ciudad" readonly>
                <input  class="form-group form-control data"type="text" value="<?= $datos->getCalle(); ?>" name="calle" readonly>
                <input  class="form-group form-control data"type="text" value="<?= $datos->getPortal(); ?>" name="portal" readonly>
                <input  class="form-group form-control data"type="text" value="<?= $datos->getEmail(); ?>" name="email" readonly>
                <input  class="form-group form-control data"type="text" value="<?= $datos->getTelefono(); ?>" name="telefono" readonly>
                <input  class="form-group form-control data"type="text" value="<?= $datos->getContacto(); ?>" name="contacto" readonly> 

                restaurante <select name="restaurante" class="form-control form-group" readonly>
                    <option value="0" id="otpr0">No</option>
                    <option value="1" id="optr1">Si</option>
                </select>                  


                hotel <select name="hotel" class="form-control form-group"  readonly>
                    <option value="0" id="opth0">No</option>
                    <option value="1" id="opth1">Si</option>
                </select>

                <input type="submit" class="btn btn-success form-group" hidden="" value="Guardar">
                <button class="btn btn-warning text-white form-group" id="beditar">Editar</button>


            </form>           
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nombre Vino</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Porcentaje</th>
                        <th scope="col"></th>
                </thead>
                <tbody><?php
                    foreach ($datos->getVinos() as $vino) {
                        ?>    <tr>
                            <th scope="row"><?= $vino['id']; ?></th>
                            <td><?= $vino['nombre']; ?></td>
                            <td><?php
                                switch ($vino['tipo']) {
                                    case 1: echo'tinto';
                                        break;
                                    case 2: echo'rosado';
                                        break;
                                    case 3: echo'blanco';
                                        break;
                                }
                                ?></td>
                            <td><?= $vino['porcentaje']; ?>%</td>
                            <td>
                                <a href="./index.php?controller=vino&action=det&id=<?= $vino['id']; ?>">
                                    <button type="button" class="btn btn-info">Info</button>
                                </a>
                                <a href="./index.php?controller=vino&action=d&idvino=<?= $vino['id']; ?>&id=<?= $_GET['id'] ?>">
                                    <button type="button" class="btn btn-danger">Borrar</button>
                                </a>
                            </td>
                        </tr>


                        <?php
                    }
                    ?></tbody>
            </table><?php ?>
            <a href="./index.php?controller=vino&action=nv&id=<?= $_GET['id'] ?>"><button type="button" class="btn btn-success">Nuevo Vino</button></a>
            <a href="./index.php">
                <button type="button" class="btn btn-secondary">Atras</button>
            </a>
        </div>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
        <script src="./JS/bodegaDetail.js"></script>
        <script src="./JS/js.js"></script>
    </body>

</html>
