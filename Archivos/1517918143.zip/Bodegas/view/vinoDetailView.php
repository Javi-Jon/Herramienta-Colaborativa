<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    </head>
    <body>
        <div class="container ">
            <h1><?= $datos->nombre; ?></h1>
            <div class="row">
                <img src="./img/<?= $datos->tipo; ?>.jpg" class="img-thumbnail img-responsive col-md-4"  width="200px">
                <div class="col-md-8">
                    <form method="POST" action="./index.php?controller=vino&action=u">
                      
                       
                        <input  type="hidden" value="<?= $datos->id; ?>" name="idvino" >
                        <input  type="hidden" value="<?= $datos->bodega; ?>" name="bodega" >
                        Nombre 
                        <input class="form-group form-control data" type="text" value="<?= $datos->nombre; ?>" name="nombre" readonly >
                        Descripcion
                        <textarea class="form-group form-control data"  name="descripcion" readonly><?= $datos->descripcion; ?>                     
                    </textarea>
                        Tipo 
                        <input type="hidden" name="tipovinoDefault" value="<?= $datos->tipo;?>">
                        <select name="tipo" class="form-group form-control data" name="tipo" readonly >
                            <option value="1"id="opt1">Tinto</option>
                            <option value="2"id="opt2" >Rosado</option>
                            <option value="3"id="opt3" >Blanco</option>
                        </select>
                        Alcohol(%) 
                        <input class="form-group form-control data" type="number" value="<?= $datos->porcentaje; ?>" name="porcentaje" readonly>
                        Año
                          <input class="form-group form-control data" type="number" value="<?= $datos->ano; ?>" name="ano" readonly>
                      
                            <input type="submit" class="btn btn-success" hidden="" value="Guardar">
                             <button class="btn btn-warning text-white" id="beditar">Editar</button>
                     <a class="btn btn-secondary" href="./index.php?controller=bodega&action=det&id=<?= $datos->bodega; ?>">Atras</a>
                           
                    </form> 
                    
                   
                </div>   
            </div> 
        </div> 

        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
        <script src="./JS/vinoDetail.js"></script>
        <script src="./JS/js.js"></script>
    </body>
</html>
