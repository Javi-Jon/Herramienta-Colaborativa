<?php

require_once 'ControllerGenerico.php';
require_once __DIR__ . '/../modelo/Vino.php';

class VinoController extends Controller {

    function run($action) {

        switch ($action) {
            case 'c':
                $this->save();
                break;
            case 'r':
                $this->getAll();
                break;
            case 'ri':
                $this->getById();
                break;
            case 'u':
                $this->update();
                break;
            case 'd':
                $this->delete();
                break;
            case'nv':
                $this->nuevoVino();
                break;
            case'det':
                $this->detalle();
                break;
        }
    }

    function save() {

        if (isset($_POST['nombre'])) {
            $vino = new Vino();
            $vino->setNombre($_POST['nombre']);
            $vino->setDescripcion($_POST['descripcion']);
            $vino->setAno($_POST['ano']);
            $vino->setPorcentaje($_POST['porcentaje']);
            $vino->setTipo($_POST['tipo']);
            $vino->setBodega($_POST['bodega']);
            
            $vino->create();
            $bodegaAux = $vino->getBodega();
            header("Location: ./index.php?controller=bodega&action=det&id=$bodegaAux");
        } else {
            header("Location: index.php");
        }
    }

    function nuevoVino() {
        $this->view('nuevoVino', []);
    }

    function detalle() {
        if (isset($_GET['id'])) {
            $vino = new Vino();
            $vino->setId($_GET['id']);
            $vino = $vino->getVinoById();
        }
        //$bodega->setVinos(); 
        $this->view('vinoDetail', $vino);
    }

    function delete() {
        if (isset($_GET['idvino'])) {
            $vino = new Vino();
            $vino->setId($_GET['idvino']);


            $vino->deleteVino();
        }
        $bodegaAux = $_GET['id'];
        header("Location: ./index.php?controller=bodega&action=det&id=$bodegaAux");
    }
    function update(){
       
        if(isset($_POST['idvino'])){     
           $vino = new Vino();
           $vino->setId($_POST['idvino']);
            $vino->setNombre($_POST['nombre']);
            $vino->setDescripcion($_POST['descripcion']);
            $vino->setAno($_POST['ano']);           
            $vino->setPorcentaje($_POST['porcentaje']); 
            $vino->setTipo($_POST['tipo']);
            
           $vino->updateVino();
           $bodegaAux = $_POST['bodega'];
            header("Location: ./index.php?controller=bodega&action=det&id=$bodegaAux");
        } else {
        header("Location: index.php");    
        }
        
    }
}
