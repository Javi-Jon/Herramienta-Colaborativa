<?php
require_once __DIR__ .'./ModeloBD.php';
class Bodega extends BD {
    
    private $id;


    private $nombre;
    private $provincia;
    private $ciudad;
    private $calle;
    private $portal;
    private $email;
    private $telefono;
    private $contacto;
    private $fundacion;
    private $restaurante;
    private $hotel;
    
    private $vinos;
    
    
    private $tabla='bodegas';
    
    
    function __construct() {
      
    }
    function getId() {
        return $this->id;
    }

    function setId($id) {
        $this->id = $id;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getProvincia() {
        return $this->provincia;
    }

    function getCiudad() {
        return $this->ciudad;
    }

    function getCalle() {
        return $this->calle;
    }

    function getPortal() {
        return $this->portal;
    }

    function getEmail() {
        return $this->email;
    }

    function getTelefono() {
        return $this->telefono;
    }

    function getContacto() {
        return $this->contacto;
    }

    function getFundacion() {
        return $this->fundacion;
    }

    function getRestaurante() {
        return $this->restaurante;
    }

    function getHotel() {
        return $this->hotel;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setProvincia($provincia) {
        $this->provincia = $provincia;
    }

    function setCiudad($ciudad) {
        $this->ciudad = $ciudad;
    }

    function setCalle($calle) {
        $this->calle = $calle;
    }

    function setPortal($portal) {
        $this->portal = $portal;
    }

    function setEmail($email) {
        $this->email = $email;
    }

    function setTelefono($telefono) {
        $this->telefono = $telefono;
    }

    function setContacto($contacto) {
        $this->contacto = $contacto;
    }

    function setFundacion($fundacion) {
        $this->fundacion = $fundacion;
    }

    function setRestaurante($restaurante) {
        $this->restaurante = $restaurante;
    }

    function setHotel($hotel) {
        $this->hotel = $hotel;
    }
    function getVinos() {
        return $this->vinos;
    }

    function setVinos($vinos) {
        $this->vinos = $vinos;
    }

        
    function create(){
        $param=[
        'nombre'=>$this->getNombre(),      
        'provincia'=>$this->getProvincia(),
        'ciudad'=>$this->getCiudad(),
        'calle'=>$this->getCalle(),
        'portal'=>$this->getPortal(), 
        'email'=>$this->getEmail(),
        'telefono'=>$this->getTelefono(),
        'contacto'=>$this->getContacto(), 
        'fundacion'=>$this->getFundacion(), 
        'restaurante'=>$this->getRestaurante(), 
        'hotel'=>$this->getHotel()
        ];
        
        $this->insert("INSERT INTO $this->tabla (nombre, provincia, ciudad, calle, portal, email,telefono,contacto, fundacion, restaurante,hotel) VALUES(:nombre,:provincia,:ciudad,:calle,:portal,:email,:telefono,:contacto,:fundacion,:restaurante,:hotel)", $param);
    }
    function getBodegas(){
       $bodegas= $this->fSelectN("SELECT id,nombre,provincia,ciudad,calle,portal,email,telefono,contacto,fundacion,restaurante,hotel FROM $this->tabla",[]);
       
       return $bodegas;
    }
    function getBodegaById(){
       $bodega= $this->fSelectO("SELECT nombre,provincia,ciudad,calle,portal,email,telefono,contacto,fundacion,restaurante,hotel FROM $this->tabla WHERE id=:id",['id'=>$this->getId()]);
       
       return $bodega;
    }
    function deleteBodega(){
        $this->delete("DELETE FROM $this->tabla WHERE id=:id", ['id'=> $this->getId()]);
    }
    function updateBodega() {
        $this->update("UPDATE bodegas SET nombre=:nombre,provincia=:provincia,ciudad=:ciudad,calle=:calle,portal=:portal,email=:email,telefono=:telefono,contacto=:contacto,fundacion=:fundacion,restaurante=:restaurante,hotel=:hotel WHERE id=:id",
               ['nombre'=>$this->getNombre(),
                'provincia'=> $this->getProvincia(),
                'ciudad'=> $this->getCiudad(),
                'calle'=> $this->getCalle(),
                'portal'=> $this->getPortal(),
                'email'=> $this->getEmail(),
                'telefono'=> $this->getTelefono(),
                'contacto'=> $this->getContacto(),
                'fundacion'=> $this->getFundacion(),
                'restaurante'=> $this->getRestaurante(),
                'hotel'=> $this->getHotel(),
                'id'=> $this->getId()]);
    }
 

}

