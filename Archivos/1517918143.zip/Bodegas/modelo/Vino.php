<?php

require_once __DIR__ . './ModeloBD.php';

class Vino extends BD {

    private $id;
    private $nombre;
    private $descripcion;
    private $ano;
    private $tipo;
    private $porcentaje;
    private $bodega;
    private $tabla = 'vinos';

    function getId() {
        return $this->id;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getDescripcion() {
        return $this->descripcion;
    }

    function getAno() {
        return $this->ano;
    }

    function getTipo() {
        return $this->tipo;
    }

    function getPorcentaje() {
        return $this->porcentaje;
    }

    function getBodega() {
        return $this->bodega;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    function setAno($ano) {
        $this->ano = $ano;
    }

    function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    function setPorcentaje($porcentaje) {
        $this->porcentaje = $porcentaje;
    }

    function setBodega($bodega) {
        $this->bodega = $bodega;
    }

    function create() {
        $param = [
            'nombre' => $this->getNombre(),
            'descripcion' => $this->getDescripcion(),
            'ano' => $this->getAno(),
            'tipo' => $this->getTipo(),
            'porcentaje' => $this->getPorcentaje(),
            'bodega' => $this->getBodega()
        ];

        $this->insert("INSERT INTO $this->tabla (nombre, descripcion, ano, tipo, porcentaje, bodega) VALUES(:nombre,:descripcion,:ano,:tipo,:porcentaje,:bodega)", $param);
    }

    function getVinoById() {
        $vino = $this->fSelectO("SELECT id,nombre, descripcion, ano, tipo, porcentaje, bodega FROM $this->tabla WHERE id=:id", ['id' => $this->getId()]);

        return $vino;
    }

    function getVinosByBodega() {
        try {
            $vinos = $this->fSelectN("SELECT id,nombre, descripcion, ano, tipo, porcentaje, bodega FROM $this->tabla WHERE bodega=:bodega", ['bodega' => $this->getBodega()]);

            return $vinos;
        } catch (Exception $ex) {
            return $ex;
        }
    }

    function deleteVino() {
        try {
           $this->delete("DELETE FROM $this->tabla WHERE id=:id ", ['id'=> $this->getId()]);
        } catch (Exception $ex) {
            return $ex;
        }
    }
    function updateVino() {
        try{
            $this->update("UPDATE vinos SET nombre=:nombre,descripcion=:descripcion,ano=:ano,tipo=:tipo,porcentaje=:porcentaje WHERE id=:id", ['nombre'=> $this->getNombre(),'descripcion'=> $this->getDescripcion(),'ano'=> $this->getAno(),'tipo'=> $this->getTipo(),'porcentaje'=> $this->getPorcentaje(),'id'=> $this->getId()]);
            
        } catch (Exception $ex) {

        }
       
    }

}
