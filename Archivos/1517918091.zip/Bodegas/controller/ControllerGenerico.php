<?php
 class Controller {

     public function view($vista,$datos){
         
        require_once  __DIR__ ."/../view/" . $vista . "View.php";

    }
    

}

