<?php
require_once 'ControllerGenerico.php';
require_once __DIR__ . '/../modelo/Bodega.php';

class BodegaController extends Controller {

    //private $self='Bodega';
            
    function __construct() {
        
    }
    function run($action) {
        switch ($action) {
            case 'c':
                $this->save();
                break;
            case 'r':
                $this->getAll();
                break;
            case 'ri':
                $this->getById();
                break;
            case 'u':
                $this->update();
                break;
            case 'd':
                $this->delete();
                break;
            case'nv':
                $this->nuevaBodega();
                break;
            case'det':
                $this->detalle();
                break;
        }
    }
    function save() {

        if (isset($_POST['nombre'])) {
            $bodega = new Bodega();
                $bodega->setNombre($_POST['nombre']);
                $bodega->setProvincia($_POST['provincia']);
                $bodega->setCiudad($_POST['ciudad']);
                $bodega->setCalle($_POST['calle']);
                $bodega->setPortal($_POST['portal']);
                $bodega->setEmail($_POST['email']);
                $bodega->setTelefono($_POST['telefono']);
                $bodega->setContacto($_POST['contacto']);
                $bodega->setFundacion($_POST['fundacion']);
                $bodega->setRestaurante($_POST['restaurante']);
                $bodega->setHotel($_POST['hotel']);
            $bodega->create();
            
        }
        header('Location:index.php');
    }
    function getAll(){
        $bodega=new Bodega();
        $bodegas=$bodega->getBodegas();
        return $bodegas;
    }
    function getById(){
        $bodega=new Bodega();
        $bodega->setId($_GET['id']);
        $bodega->getBodegaById();
    }
    function nuevaBodega(){
        $this->view('nuevaBodega', []);
    }
    function detalle() {
        $bodega =new Bodega();
        $bodega->setId($_GET['id']);
       $bod= $bodega->getBodegaById();
                $bodega->setNombre($bod->nombre);
                $bodega->setProvincia($bod->provincia);
                $bodega->setCiudad($bod->ciudad);
                $bodega->setCalle($bod->calle);
                $bodega->setPortal($bod->portal);
                $bodega->setEmail($bod->email);
                $bodega->setTelefono($bod->telefono);
                $bodega->setContacto($bod->contacto);
                $bodega->setFundacion($bod->fundacion);
                $bodega->setRestaurante($bod->restaurante);
                $bodega->setHotel($bod->hotel);
$bodega->setVinos($this->getVinosBodega($_GET['id']));
       //$bodega->setVinos(); 
      $b=$bodega;
        $this->view('bodegaDetail',$b);
    }
  function getVinosBodega($bodega){

$vino=new Vino();
$vino->setBodega($bodega);
      $vinos= $vino->getVinosByBodega();
             
       return $vinos;
    }
    function delete(){
        $bodega =new Bodega();
        $bodega->setId($_GET['id']);
        $bodega->deleteBodega();
        header('Location:index.php');
    }
     function update(){
       
        if(isset($_POST['id'])){     
           $bodega=new Bodega();
           $bodega->setId($_POST['id']);
          $bodega->setNombre($_POST['nombre']);
                $bodega->setProvincia($_POST['provincia']);
                $bodega->setCiudad($_POST['ciudad']);
                $bodega->setCalle($_POST['calle']);
                $bodega->setPortal($_POST['portal']);
                $bodega->setEmail($_POST['email']);
                $bodega->setTelefono($_POST['telefono']);
                $bodega->setContacto($_POST['contacto']);
                $bodega->setFundacion($_POST['fundacion']);
                $bodega->setRestaurante($_POST['restaurante']);
                $bodega->setHotel($_POST['hotel']);
            
           $bodega->updateBodega();
           $bodegaAux = $_POST['id'];
            header("Location: ./index.php?controller=bodega&action=det&id=$bodegaAux");
        } else {
        header("Location: index.php");    
        }
        
    }
}
