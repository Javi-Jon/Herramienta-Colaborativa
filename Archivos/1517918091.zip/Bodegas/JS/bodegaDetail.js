var hotel=$('[name=hotelDefault').val();
$('#opth'+hotel+'').attr('selected','selected');


var restaurante=$('[name=restauranteDefault').val();
$('#optr'+restaurante+'').attr('selected','selected');

